package crm.dao;

import java.util.List;

import crm.domain.BaseDict;

public interface BaseDictDao extends BaseDao<BaseDict>{

	List<BaseDict> finByTypeCode(String dict_type_code);

}
