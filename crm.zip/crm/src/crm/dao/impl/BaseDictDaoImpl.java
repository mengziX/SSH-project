package crm.dao.impl;

import java.util.List;

import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import crm.dao.BaseDictDao;
import crm.domain.BaseDict;

public class BaseDictDaoImpl extends BaseDaoImpl<BaseDict> implements BaseDictDao {

//	public BaseDictDaoImpl() {
//		super(BaseDict.class);
//	}

	@Override
	public List<BaseDict> finByTypeCode(String dict_type_code) {
		return 	(List<BaseDict>) this.getHibernateTemplate().find("from BaseDict where dict_type_code = ?",dict_type_code);
	}
	
}
