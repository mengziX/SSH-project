package crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.expression.spel.ast.Projection;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import crm.dao.LinkManDao;
import crm.domain.Customer;
import crm.domain.LinkMan;

public class LinkManDaoImpl extends BaseDaoImpl<LinkMan> implements LinkManDao {
	
//	public LinkManDaoImpl() {
//		super(LinkMan.class);
//	}




}
