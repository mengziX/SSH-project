package crm.dao.impl;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.orm.hibernate5.support.HibernateDaoSupport;

import crm.dao.CustomerDao;
import crm.domain.Customer;

public class CustomerDaoimpl extends BaseDaoImpl<Customer> implements CustomerDao {

//	public CustomerDaoimpl() {
//		super(Customer.class);
//	}


}
