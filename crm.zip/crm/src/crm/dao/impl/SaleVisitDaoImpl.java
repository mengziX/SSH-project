package crm.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import crm.dao.BaseDao;
import crm.dao.SaleVisitDao;
import crm.domain.SaleVisit;
/**
 * �ͻ��ݷü�¼
 * @author asus
 *
 */
public class SaleVisitDaoImpl extends BaseDaoImpl<SaleVisit> implements SaleVisitDao {
	
}
