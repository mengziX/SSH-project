package crm.dao;

import java.util.List;

import org.hibernate.criterion.DetachedCriteria;

import crm.domain.Customer;
import crm.domain.LinkMan;

public interface LinkManDao extends BaseDao<LinkMan> {

}
