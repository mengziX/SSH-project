package crm.dao;

import crm.domain.SaleVisit;

public interface SaleVisitDao extends BaseDao<SaleVisit> {

}
