package crm.web.interceptor;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;

import crm.domain.User;

public class PrivilegeInterceptor extends MethodFilterInterceptor{

	@Override
	protected String doIntercept(ActionInvocation invocation) throws Exception {
		User existUser=(User) ServletActionContext.getRequest().getSession().getAttribute("existUser");
		if(existUser==null){
			//�������Ϣ
			ActionSupport actionSupport = (ActionSupport) invocation.getAction();
			actionSupport.addActionError("����û�е�¼����Ȩ�޷���");
			return actionSupport.LOGIN;
		}else{
			//�Ѿ���½
			return invocation.invoke();
		}
	}

}
