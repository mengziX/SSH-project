package crm.web.action;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import crm.domain.Customer;
import crm.domain.PageBean;
import crm.service.CustomerService;
import crm.utils.UploadUtils;
import net.sf.json.JSONArray;
import net.sf.json.JsonConfig;

public class CustomerAction extends ActionSupport implements ModelDriven<Customer>{
	private Customer customer = new Customer();
	@Override
	public Customer getModel() {
		return customer;
	}
	private CustomerService customerService;
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}
	public String saveUI(){
		return "saveUI";
	}
	
	private String uploadFileName;
	private File upload;
	private String uploadContentType;
	//����ͻ�
	public String save() throws IOException{
		if(upload != null){
			String path = "F:/upload";
			String uuidFileName = UploadUtils.getUUidFileName(uploadFileName);      
			String realPath = UploadUtils.getPath(uuidFileName);
			String url = path+realPath;
			File file =  new File(url);
			if(!file.exists()){
				file.mkdir();
			}
			File dictFile = new File(url+"/"+uuidFileName);
			FileUtils.copyFile(upload, dictFile);
			customer.setCust_image(url+"/"+uuidFileName);
		}
		customerService.save(customer);
		return "saveSuccess";
	}
	//ҳ��
	private Integer currPage =1;
	
	public void setCurrPage(Integer currPage) {
		if(currPage  == null){
			currPage = 1;
		}
		this.currPage = currPage;
	}
	private Integer pageSize =3;
	public void setPageSize(Integer pageSize) {
		if(pageSize  == null){
			pageSize = 3;
		}
		this.pageSize = pageSize;
	}
	//find    
	public String findAll(){
		DetachedCriteria detachedCriteria = DetachedCriteria.forClass(Customer.class);
		if(customer.getCust_name()!=null ){
			System.out.println("customer.Nameִ��");
			detachedCriteria.add(Restrictions.like("cust_name","%"+customer.getCust_name()+"%"));
		}
		
		if(customer.getBaseDictSource()!=null){
			if(customer.getBaseDictSource().getDict_id()!= null 
				&& !"".equals(customer.getBaseDictSource().getDict_id())){
				System.out.println("CustomerSourceִ��");
			detachedCriteria.add(Restrictions.eq("baseDictSource.dict_id",customer.getBaseDictSource().getDict_id()));
			}
		}
		if(customer.getBaseDictLevel()!=null ){
			if(customer.getBaseDictLevel().getDict_id()!= null 
			&& !"".equals(customer.getBaseDictLevel().getDict_id())){
			detachedCriteria.
			add(Restrictions.eq("baseDictLevel.dict_id",customer.getBaseDictLevel().getDict_id()));
			}
		}
		if(customer.getBaseDictIndustry()!=null && customer.getBaseDictIndustry().getDict_id()!=null){
			if(customer.getBaseDictIndustry().getDict_id()!= null 
				&& !"".equals(customer.getBaseDictIndustry().getDict_id())){
			detachedCriteria
			.add(Restrictions.eq("baseDictIndustry.dict_id",customer.getBaseDictIndustry().getDict_id()));
			}
		}
		PageBean<Customer> pageBean = customerService.findByPage(detachedCriteria,currPage,pageSize);
		ActionContext.getContext().getValueStack().push(pageBean);
		return "findAll";
	}
	public String delete(){
		customer = customerService.findById(customer.getCust_id());
		if(customer.getCust_image()!=null){
			File file = new File(customer.getCust_image());
			if(file.exists())
			   file.delete();
		}
		customerService.delete(customer);
		return "deleteSuccess";
	} 
	public String edit(){
		customer = customerService.findById(customer.getCust_id());
//		ActionContext.getContext().getValueStack().push(customer);
		return "editSuccess";
	}
	public String update() throws IOException{
		
		if(upload != null){
			String cust_image = customer.getCust_image(); 
			if(cust_image != null || !"".equals(cust_image)){
				File file = new File(cust_image);
				file.delete();
			}
			String path = "F:/upload";
			String uuidFileName = UploadUtils.getUUidFileName(uploadFileName);      
			String realPath = UploadUtils.getPath(uuidFileName);
			String url = path+realPath;
			File file =  new File(url);
			if(!file.exists()){
				file.mkdir();
			}
			File dictFile = new File(url+"/"+uuidFileName);
			FileUtils.copyFile(upload, dictFile);
			customer.setCust_image(url+"/"+uuidFileName);
		}
		System.out.println(customer);
		customerService.update(customer);
		return "updateSuccess";
	}
	public String findAllCustomer() throws IOException{
		List<Customer> list= customerService.findAll();
		JsonConfig jsonConfig = new JsonConfig();
		jsonConfig.setExcludes(new String[]{"linkMans","baseDictSource","baseDictIndustry","baseDictLevel"});
		JSONArray jsonArray = JSONArray.fromObject(list,jsonConfig);
		ServletActionContext.getResponse().setContentType("text/html; charset=UTF-8");
		ServletActionContext.getResponse().getWriter().println(jsonArray.toString());
		return NONE;
	}
}
