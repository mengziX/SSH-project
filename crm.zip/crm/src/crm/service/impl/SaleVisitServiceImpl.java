package crm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.criterion.DetachedCriteria;
import org.springframework.transaction.annotation.Transactional;

import crm.service.SaleVisitService;
import crm.dao.SaleVisitDao;
import crm.domain.PageBean;
import crm.domain.SaleVisit;
@Transactional
public class SaleVisitServiceImpl implements SaleVisitService {
	@Resource(name="SaleVisitDao")
	private SaleVisitDao SaleVisitDao;

	@Override
	public PageBean<SaleVisit> findByPage(DetachedCriteria detachedCriteria, Integer currage, Integer pageSize) {
		PageBean<SaleVisit> pageBean = new PageBean<SaleVisit>();
		pageBean.setCurrage(currage);
		pageBean.setPageSize(pageSize);
		Integer totalCount = SaleVisitDao.findCount(detachedCriteria);
		pageBean.setTotalCount(totalCount);
		double tc = totalCount;
		Double num = Math.ceil(tc/pageSize);
		pageBean.setTotalPage(num.intValue());
		Integer begin =(currage -1)*pageSize;
		List<SaleVisit> list = SaleVisitDao.findByPage(detachedCriteria,begin,pageSize);
		pageBean.setList(list);
		return pageBean;
	}

	@Override
	public void save(SaleVisit saleVisit) {
		SaleVisitDao.save(saleVisit);
	}
	
}
