package crm.service.impl;

import java.util.List;

import crm.dao.BaseDictDao;
import crm.domain.BaseDict;
import crm.service.BaseDictService;

public class BaseDictServiceImpl implements BaseDictService {
	private BaseDictDao baseDictDao;

	public BaseDictDao getBaseDictDao() {
		return baseDictDao;
	}

	public void setBaseDictDao(BaseDictDao basseDictDao) {
		this.baseDictDao = basseDictDao;
	}

	@Override
	public List<BaseDict> finByTypeCode(String dict_type_code) {
		return baseDictDao.finByTypeCode(dict_type_code);
	}
	
}
