package crm.service;

import org.hibernate.criterion.DetachedCriteria;

import crm.domain.PageBean;
import crm.domain.SaleVisit;

public interface SaleVisitService {

	PageBean<SaleVisit> findByPage(DetachedCriteria detachedCriteria, Integer currPage, Integer pageSize);

	void save(SaleVisit saleVisit);

}
