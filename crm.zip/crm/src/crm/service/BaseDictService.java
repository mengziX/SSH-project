package crm.service;

import java.util.List;

import crm.domain.BaseDict;

public interface BaseDictService {

	List<BaseDict> finByTypeCode(String dict_type_code);

}
