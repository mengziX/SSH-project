package crm.service;

import java.util.List;

import crm.domain.User;

public interface UserService {

	void regist(User user);

	User login(User user);

	List<User> findAll();

}
